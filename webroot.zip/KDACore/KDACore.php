<?php

namespace KDAWebLab;

/**
 * Core - test core app class
 * @author Andrey Lisnyak <munspel@ukr.net>
 */
class KDACore {

    public function __construct() {
        echo "Kalnichenko Dmitriy 5133";
    }
}
